#!/bin/bash
export $(cat  variables | xargs)

#write your ci/cd code here
